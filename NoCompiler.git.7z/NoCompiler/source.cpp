int main()
{
	int c;
	int d;
	if(c == d)
	{
		int a;
		a = 3;
	}
	else
	{
		int b;
		b = a+b;
		a = 10;
	}
	while(c == d)
	{
		a=3;
	}
	for( c = 0 ; c<10 ; c = c + 1;)
	{
		a = 3;
	}
}