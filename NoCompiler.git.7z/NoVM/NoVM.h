#ifndef NO_VM_H
#define NO_VM_H

#include "../NoCompiler/SemanticAnalyzer.h"
#include "../NoCompiler/lexer.h"
#include <iostream>
#include <fstream>

using namespace std;
#endif